Colocar imagens dentro de uma pasta chamada 'img' após a extração dos arquivos
